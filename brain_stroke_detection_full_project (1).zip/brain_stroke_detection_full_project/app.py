import os, time
import streamlit as st
import numpy as np
import tensorflow as tf
from PIL import Image
import cv2

st.set_page_config(page_title="Brain Scan Research Prototype", page_icon="🧠",
                   layout="centered")
st.title("🧠 Brain Stroke Detection")
st.caption("Deep transfer learning research prototype — not a medical diagnostic tool.")

MODEL_OPTIONS = {
    "ResNet50": "models/resnet50_best.keras",
    "VGG16": "models/vgg16_best.keras",
    "InceptionV3": "models/inceptionv3_best.keras"
}

@st.cache_resource
def load_model(path):
    return tf.keras.models.load_model(path)

def create_gradcam(model, image):
    """Grad-CAM for the final convolutional layer of the nested CNN backbone."""
    nested = [layer for layer in model.layers if isinstance(layer, tf.keras.Model)]
    if not nested:
        raise ValueError("CNN backbone was not found.")
    backbone = nested[0]
    conv_layer = next((layer for layer in reversed(backbone.layers)
                       if isinstance(layer, tf.keras.layers.Conv2D)), None)
    if conv_layer is None:
        raise ValueError("Convolution layer was not found.")

    grad_model = tf.keras.Model(
        inputs=model.input,
        outputs=[conv_layer.output, model.output]
    )
    x = np.expand_dims(image.astype("float32"), axis=0)
    with tf.GradientTape() as tape:
        conv_outputs, predictions = grad_model(x, training=False)
        loss = predictions[:, 0]
    grads = tape.gradient(loss, conv_outputs)
    weights = tf.reduce_mean(grads, axis=(1, 2))
    heatmap = tf.reduce_sum(weights[:, None, None, :] * conv_outputs, axis=-1)[0]
    heatmap = tf.maximum(heatmap, 0)
    heatmap = heatmap / (tf.reduce_max(heatmap) + tf.keras.backend.epsilon())
    return heatmap.numpy()

def overlay_heatmap(original_rgb, heatmap):
    heatmap = cv2.resize(heatmap, (original_rgb.shape[1], original_rgb.shape[0]))
    heatmap_uint8 = np.uint8(255 * heatmap)
    colored = cv2.applyColorMap(heatmap_uint8, cv2.COLORMAP_JET)
    colored = cv2.cvtColor(colored, cv2.COLOR_BGR2RGB)
    return cv2.addWeighted(original_rgb, 0.60, colored, 0.40, 0)

st.warning(
    "This academic prototype is not clinically validated. It must not be used to "
    "diagnose, rule out, grade, or treat a stroke. If stroke is suspected, seek "
    "emergency medical care immediately."
)

available = {name: path for name, path in MODEL_OPTIONS.items() if os.path.exists(path)}
if not available:
    st.error("No trained model found. Train one first using the commands in README.md.")
    st.stop()

choice = st.selectbox("Choose a trained model", list(available.keys()))
uploaded = st.file_uploader("Upload a brain scan image (PNG/JPG/JPEG)",
                            type=["png", "jpg", "jpeg"])

if uploaded:
    try:
        pil_image = Image.open(uploaded).convert("RGB")
        original = np.array(pil_image)
        resized = pil_image.resize((224, 224))
        model_input = np.array(resized).astype("float32")

        st.image(original, caption="Uploaded image", use_container_width=True)
        model = load_model(available[choice])

        if st.button("Analyze image"):
            start = time.time()
            probability = float(model.predict(np.expand_dims(model_input, 0),
                                              verbose=0)[0][0])
            elapsed = time.time() - start
            predicted = "Stroke class" if probability >= 0.5 else "Non-stroke class"
            st.subheader("Model output")
            st.write(f"Predicted class: **{predicted}**")
            st.write(f"Model score for stroke class: **{probability:.2%}**")
            st.write(f"Processing time: **{elapsed:.2f} seconds**")
            st.caption("The score is a model output, not a medical probability or diagnosis.")

            try:
                heatmap = create_gradcam(model, model_input)
                st.image(overlay_heatmap(original, heatmap),
                         caption="Grad-CAM visualization (model attention, not proof of a lesion)",
                         use_container_width=True)
            except Exception as cam_error:
                st.info(f"Grad-CAM could not be generated for this model: {cam_error}")
    except Exception as error:
        st.error(f"Could not process this image: {error}")

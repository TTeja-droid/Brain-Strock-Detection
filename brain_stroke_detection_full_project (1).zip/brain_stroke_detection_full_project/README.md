# Brain Stroke Detection Using Deep Transfer Learning

A Python/TensorFlow academic research prototype for binary classification of labeled brain MRI/CT image files into `stroke` and `non_stroke` classes. It compares ResNet50, VGG16 and InceptionV3, reports held-out test metrics, and provides a Streamlit upload interface with optional Grad-CAM visualization.

## Important medical limitation

This is educational/research code, not a clinically validated medical device. It must not be used to diagnose or rule out stroke, determine severity, or guide treatment. A suspected stroke is an emergency: seek immediate medical care. Never upload identifiable patient data to an unapproved service.

## 1. Requirements

- Windows 10/11, macOS or Linux
- Python 3.10 or 3.11 recommended
- VS Code
- Internet connection for first-time download of ImageNet pretrained weights
- A labeled and legally usable brain scan image dataset

## 2. Open the project in VS Code

Open this folder in VS Code. Open Terminal → New Terminal.

Create and activate a virtual environment on Windows:

```bash
py -3.11 -m venv venv
venv\Scripts\activate
```

On macOS/Linux:

```bash
python3.11 -m venv venv
source venv/bin/activate
```

Install packages:

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## 3. Add your dataset

Place images into this exact structure. Keep the same class folder names in all three splits:

```text
data/
  train/
    non_stroke/
    stroke/
  val/
    non_stroke/
    stroke/
  test/
    non_stroke/
    stroke/
```

- `train`: used to learn model weights.
- `val`: used during training for early stopping and model selection.
- `test`: held back until final evaluation.

The report describes a 70:20:10 train/validation/test split. Split at the **patient level**, not randomly by individual scan slices, if patient identifiers are available. Otherwise images from one patient can leak into multiple splits and inflate results. Do not put duplicate images in different splits.

The code expects class order `non_stroke` then `stroke`, which is the alphabetical order used by Keras for these folder names. Use only correctly labeled data.

## 4. Train each architecture

Run from the project root:

```bash
python src/train.py --data data --architecture resnet50 --epochs 30
python src/train.py --data data --architecture vgg16 --epochs 30
python src/train.py --data data --architecture inceptionv3 --epochs 30
```

To fine-tune the deeper layers after the initial transfer-learning run:

```bash
python src/train.py --data data --architecture resnet50 --epochs 10 --fine-tune
```

Training can take a long time on CPU. A GPU is recommended. The first run downloads pretrained ImageNet weights.

## 5. Read evaluation results

After each run, see:
- `models/<architecture>_best.keras`
- `reports/<architecture>_metrics.json`
- `reports/<architecture>_history.json`

The test report includes accuracy, precision, recall, F1-score, confusion matrix and ROC-AUC when both classes are present. Do not select a model based only on accuracy. In a medical research setting, inspect false negatives, sensitivity/recall, class balance, external validation and confidence intervals with a qualified supervisor.

## 6. Start the web application

After training at least one model:

```bash
streamlit run app.py
```

Streamlit will print a local URL, usually `http://localhost:8501`. Open it in your browser, choose the model, upload a JPG/PNG brain scan, and click **Analyze image**.

## 7. Troubleshooting

**`No trained model found`**: train one architecture first and confirm the `.keras` file exists under `models/`.

**Out of memory**: reduce `BATCH_SIZE` in `src/train.py` from 32 to 8 or 16. Close other applications.

**TensorFlow installation issue**: use Python 3.10/3.11 in a fresh virtual environment and install requirements again.

**Dataset folder error**: check exact spelling and capitalization: `train`, `val`, `test`, `stroke`, `non_stroke`.

**Very high test accuracy**: investigate duplicates, patient overlap, class imbalance and data leakage before trusting the result.

## Project files

```text
brain_stroke_detection_full_project/
  app.py
  requirements.txt
  README.md
  src/
    model.py
    train.py
    gradcam.py
  data/
    train/non_stroke, train/stroke
    val/non_stroke, val/stroke
    test/non_stroke, test/stroke
  models/
  reports/
```

## What is not included

The project report and research paper do not provide the actual labeled image dataset or trained model weights as files. You must supply a dataset with verified labels and train the models yourself. This code does not claim to reproduce the report's stated accuracy.

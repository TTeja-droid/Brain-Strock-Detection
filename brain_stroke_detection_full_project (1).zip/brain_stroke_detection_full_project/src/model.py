import tensorflow as tf
from tensorflow.keras import layers, Model
from tensorflow.keras.applications import ResNet50, VGG16, InceptionV3

IMAGE_SIZE = (224, 224)

def build_model(architecture="resnet50", learning_rate=1e-4, fine_tune=False):
    """Build a binary classifier. Inputs are RGB pixels in the 0..255 range."""
    architecture = architecture.lower()
    inputs = layers.Input(shape=(224, 224, 3), name="brain_scan")

    # Augmentation is active only during training.
    x = layers.RandomFlip("horizontal")(inputs)
    x = layers.RandomRotation(0.05)(x)
    x = layers.RandomZoom(0.10)(x)

    if architecture == "resnet50":
        preprocess = tf.keras.applications.resnet50.preprocess_input
        backbone = ResNet50(include_top=False, weights="imagenet",
                            input_shape=(224, 224, 3))
    elif architecture == "vgg16":
        preprocess = tf.keras.applications.vgg16.preprocess_input
        backbone = VGG16(include_top=False, weights="imagenet",
                         input_shape=(224, 224, 3))
    elif architecture == "inceptionv3":
        preprocess = tf.keras.applications.inception_v3.preprocess_input
        backbone = InceptionV3(include_top=False, weights="imagenet",
                               input_shape=(224, 224, 3))
    else:
        raise ValueError("architecture must be resnet50, vgg16, or inceptionv3")

    x = layers.Lambda(preprocess, name="model_preprocessing")(x)
    backbone.trainable = bool(fine_tune)
    if fine_tune:
        # Keep most pretrained layers frozen; fine-tune only the deeper layers.
        for layer in backbone.layers[:-30]:
            layer.trainable = False

    x = backbone(x, training=False)
    x = layers.GlobalAveragePooling2D()(x)
    x = layers.Dropout(0.35)(x)
    x = layers.Dense(128, activation="relu")(x)
    x = layers.Dropout(0.25)(x)
    outputs = layers.Dense(1, activation="sigmoid", name="stroke_probability")(x)

    model = Model(inputs, outputs, name=f"brain_stroke_{architecture}")
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=learning_rate),
        loss="binary_crossentropy",
        metrics=["accuracy", tf.keras.metrics.Precision(name="precision"),
                 tf.keras.metrics.Recall(name="recall")]
    )
    return model

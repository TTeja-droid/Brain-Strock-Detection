import argparse, json, os
from pathlib import Path
import numpy as np
import tensorflow as tf
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             f1_score, confusion_matrix, classification_report,
                             roc_auc_score)
from model import build_model

SEED = 42
IMG_SIZE = (224, 224)
BATCH_SIZE = 32

def load_datasets(data_dir):
    data_dir = Path(data_dir)
    required = [data_dir/"train", data_dir/"val", data_dir/"test"]
    for folder in required:
        if not folder.exists():
            raise FileNotFoundError(f"Missing folder: {folder}")
        for cls in ("non_stroke", "stroke"):
            if not (folder/cls).exists():
                raise FileNotFoundError(f"Missing class folder: {folder/cls}")

    train_ds = tf.keras.utils.image_dataset_from_directory(
        data_dir/"train", image_size=IMG_SIZE, batch_size=BATCH_SIZE,
        label_mode="binary", color_mode="rgb", shuffle=True, seed=SEED)
    val_ds = tf.keras.utils.image_dataset_from_directory(
        data_dir/"val", image_size=IMG_SIZE, batch_size=BATCH_SIZE,
        label_mode="binary", color_mode="rgb", shuffle=False)
    test_ds = tf.keras.utils.image_dataset_from_directory(
        data_dir/"test", image_size=IMG_SIZE, batch_size=BATCH_SIZE,
        label_mode="binary", color_mode="rgb", shuffle=False)

    expected = ["non_stroke", "stroke"]
    if train_ds.class_names != expected:
        raise ValueError(f"Expected class order {expected}; got {train_ds.class_names}.")
    if val_ds.class_names != expected or test_ds.class_names != expected:
        raise ValueError("Train, validation and test class folders must match exactly.")

    autotune = tf.data.AUTOTUNE
    train_ds = train_ds.prefetch(autotune)
    val_ds = val_ds.prefetch(autotune)
    test_ds = test_ds.prefetch(autotune)
    return train_ds, val_ds, test_ds

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default="data")
    parser.add_argument("--architecture", default="resnet50",
                        choices=["resnet50", "vgg16", "inceptionv3"])
    parser.add_argument("--epochs", type=int, default=30)
    parser.add_argument("--fine-tune", action="store_true")
    args = parser.parse_args()

    tf.keras.utils.set_random_seed(SEED)
    train_ds, val_ds, test_ds = load_datasets(args.data)

    os.makedirs("models", exist_ok=True)
    os.makedirs("reports", exist_ok=True)
    model_path = f"models/{args.architecture}_best.keras"

    model = build_model(args.architecture, fine_tune=args.fine_tune)
    callbacks = [
        tf.keras.callbacks.ModelCheckpoint(model_path, monitor="val_loss",
                                           save_best_only=True, verbose=1),
        tf.keras.callbacks.EarlyStopping(monitor="val_loss", patience=5,
                                         restore_best_weights=True, verbose=1),
        tf.keras.callbacks.ReduceLROnPlateau(monitor="val_loss", factor=0.2,
                                             patience=3, min_lr=1e-7, verbose=1)
    ]

    model.summary()
    history = model.fit(train_ds, validation_data=val_ds,
                        epochs=args.epochs, callbacks=callbacks)

    # Evaluate only once on the held-out test set.
    best_model = tf.keras.models.load_model(model_path)
    y_true = np.concatenate([y.numpy().ravel() for _, y in test_ds]).astype(int)
    y_prob = best_model.predict(test_ds, verbose=1).ravel()
    y_pred = (y_prob >= 0.5).astype(int)

    metrics = {
        "architecture": args.architecture,
        "test_accuracy": float(accuracy_score(y_true, y_pred)),
        "test_precision": float(precision_score(y_true, y_pred, zero_division=0)),
        "test_recall": float(recall_score(y_true, y_pred, zero_division=0)),
        "test_f1": float(f1_score(y_true, y_pred, zero_division=0)),
        "confusion_matrix": confusion_matrix(y_true, y_pred).tolist(),
        "classification_report": classification_report(
            y_true, y_pred, target_names=["non_stroke", "stroke"],
            zero_division=0, output_dict=True)
    }
    if len(np.unique(y_true)) == 2:
        metrics["test_roc_auc"] = float(roc_auc_score(y_true, y_prob))

    with open(f"reports/{args.architecture}_metrics.json", "w") as f:
        json.dump(metrics, f, indent=2)
    with open(f"reports/{args.architecture}_history.json", "w") as f:
        json.dump({k: [float(v) for v in vals]
                   for k, vals in history.history.items()}, f, indent=2)

    print("\nHELD-OUT TEST RESULTS")
    for key, value in metrics.items():
        if key != "classification_report":
            print(f"{key}: {value}")
    print(f"\nSaved model: {model_path}")
    print(f"Saved metrics: reports/{args.architecture}_metrics.json")

if __name__ == "__main__":
    main()

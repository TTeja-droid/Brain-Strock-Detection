import numpy as np
import tensorflow as tf
import cv2

def find_last_conv_layer(model):
    """Find the last Conv2D layer, including layers nested in a backbone."""
    found = []
    for layer in model.layers:
        if isinstance(layer, tf.keras.layers.Conv2D):
            found.append(layer.name)
        if isinstance(layer, tf.keras.Model):
            for sub in layer.layers:
                if isinstance(sub, tf.keras.layers.Conv2D):
                    found.append(sub.name)
    if not found:
        raise ValueError("No convolution layer found for Grad-CAM.")
    return found[-1]

def make_gradcam(model, image_array, last_conv_layer_name=None):
    """
    image_array: one RGB image, shape (224,224,3), raw pixel values 0..255.
    Returns a heatmap in 0..1.
    """
    if last_conv_layer_name is None:
        # The backbone is the nested model before the pooling head.
        nested = [layer for layer in model.layers if isinstance(layer, tf.keras.Model)]
        if not nested:
            raise ValueError("Could not locate CNN backbone.")
        backbone = nested[0]
        conv_layer = next((l for l in reversed(backbone.layers)
                           if isinstance(l, tf.keras.layers.Conv2D)), None)
        if conv_layer is None:
            raise ValueError("No convolution layer found.")
        grad_model = tf.keras.Model(
            inputs=backbone.input,
            outputs=[conv_layer.output, backbone.output])
        x = np.expand_dims(image_array.astype("float32"), axis=0)
        # Pass through preprocessing and augmentation before backbone.
        prefix = tf.keras.Model(model.input, model.layers[-5].output)
        # Safer complete-model gradient path using an intermediate nested output.
        with tf.GradientTape() as tape:
            augmented = model.layers[1](model.input) if False else tf.convert_to_tensor(x)
            prefix_out = model.get_layer("model_preprocessing")(x)
            conv_outputs, _ = grad_model(prefix_out, training=False)
            # Connect the classifier head to the backbone output by calling full model
            # through a submodel that exposes the selected conv output.
            full_grad_model = tf.keras.Model(
                model.input, [conv_layer.output, model.output])
            conv_maps, predictions = full_grad_model(x, training=False)
            score = predictions[:, 0]
            grads = tape.gradient(score, conv_maps)
    else:
        raise NotImplementedError("Pass no layer name; automatic Grad-CAM is used.")

    weights = tf.reduce_mean(grads, axis=(1, 2))
    cam = tf.reduce_sum(weights[:, tf.newaxis, tf.newaxis, :] * conv_maps, axis=-1)[0]
    cam = tf.maximum(cam, 0)
    maximum = tf.reduce_max(cam)
    cam = cam / (maximum + tf.keras.backend.epsilon())
    return cam.numpy()
